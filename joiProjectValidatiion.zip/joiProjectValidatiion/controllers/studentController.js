const Student = require('../models/studentModel')

exports. createStudent = async (req, res) => {


  try {
    const { name } = req.body;
    if (!name) {
      res.status(401).json({
        message: "Can not be blank"
      })
    }
    res.status(200).json({
      message: "user created successfully"
    })

  } catch (error) {
    res.status(500).json({
      message: error.message
    })
  }
}

