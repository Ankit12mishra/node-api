const mongoose = require ('mongoose')

const studentSchema = new mongoose.Schema({
  name:{
    type:String,
    required:true
  }
})


const User = mongoose.model('User', studentSchema);
module.exports = User;