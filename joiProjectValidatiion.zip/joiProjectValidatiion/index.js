const express = require('express')
const connectDB = require('./database/db.js');
const app = express()
const studentRoutes =  require('./routes/studentRoutes')
app.use('/api', studentRoutes)
require('dotenv').config();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
connectDB(process.env.MONGO_URL);

app.use(express.json());

app.listen(5000, () => {
    console.log('Server is running on port 5000');
});

