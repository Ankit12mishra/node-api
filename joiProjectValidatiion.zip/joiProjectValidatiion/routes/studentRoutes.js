const express = require('express')
const User = require('../models/studentModel');
const router = express.Router()

router.post('/add', async (req, res) => {
  try {
    const { name } = req.body;

    // ✅ Save to database
    const newUser = new User({ name });
    await newUser.save();

    res.status(201).json({ message: 'User created successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;