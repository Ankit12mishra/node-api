const express = require('express');
const router = express.Router();
// const authController = require('../controllers/controller.js');
// const validate = require('../middleware/validate.js');
// const registerSchema = require('../validators/valiDate');


const { registerSchema, loginSchema, updateProfile } = require('../controllers/controller.js');

router.post('/register',registerSchema);
router.post('/login', loginSchema);
router.put('/update-profile/:id', upload.single('profileImage'), updateProfile);


module.exports = router;
  

