const User = require('../model/userModels.js');

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
  const { name, email, password,role, profileImage } = req.body;
  try {
    let user = await User.findOne({ email });
    if (user) return res.status(400).json({ error: 'User already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);
    user = new User({ name, email, password: hashedPassword,role, profileImage });
    await user.save();

    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};




exports.updateProfile = async (req, res) => {
  try {
    const userId = req.params.id;
    const { email, password, role } = req.body;

    const updateData = {
      email,
      password,
      role,
    };

    // If a file is uploaded, add profileImage path
    if (req.file) {
      updateData.profileImage = `/uploads/${req.file.filename}`;
    }

    // Remove undefined/null values
    Object.keys(updateData).forEach(
      key => (updateData[key] === undefined || updateData[key] === null) && delete updateData[key]
    );

    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { $set: updateData },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.status(200).json(updatedUser);
    
  } catch (error) {
    res.status(500).json({ error: 'Server error', message: error.message });
  }
};
