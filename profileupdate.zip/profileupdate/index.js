const express = require('express');
const connectDB = require('./database/db.js');
const User = require('./models/user.js');
const upload = require('./middlewares/upload.js');
const path = require('path');

const app = express();
app.use(express.json());
app.use('/upload', express.static(path.join(__dirname, 'upload')));





require('dotenv').config();


const PORT = process.env.PORT || 3000;

connectDB(process.env.MONGO_URL);


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
