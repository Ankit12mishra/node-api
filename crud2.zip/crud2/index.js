const express = require('express');
const connectDB = require('./db/connectdb.js');
const route = require('./routes/route.js');
require('dotenv').config();
const PORT = process.env.PORT || 5000;
const app = express();

// Connect to MongoDB
connectDB(process.env.MONGO_URL);

app.use(express.json());
// route
app.use('/', route);



app.listen(5000, () => {
    console.log('Server is running on port 5000');
});