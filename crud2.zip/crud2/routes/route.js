const express = require('express');
const router = express.Router();
const crudController = require('../controllers/crud_controllers')

router.get('/',crudController.getAllRecord);
router.post('/create', crudController.createNewRecord);
router.get('/read', crudController.readRecordById);
router.put('/update',crudController.updateRecordById); 
router.delete('/delete',crudController.deleteRecordById);

module.exports = router;


