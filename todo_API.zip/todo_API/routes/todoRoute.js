const express = require('express');

const router = express.Router();

const {getTodo, createTodo, updateTodo, deleteTodo} = require('../contollers/todoControllers.js');

router.get('/', getTodo);
router.post('/', createTodo);
router.put('/:id', updateTodo);
router.delete('/:id', deleteTodo);


module.exports = router;