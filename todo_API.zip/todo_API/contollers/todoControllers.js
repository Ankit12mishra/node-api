const Todo = require('../models/todo');

const getTodo = async(req,res)=>{
  const todos =   await Todo.find();
  res.json(todos)
}


const createTodo = async(req,res)=>{
  const newTodo = new Todo(req.body);
  await newTodo.save();
  res.status(201).json({message: 'Todo is created successfully',newTodo});
}


const updateTodo = async (req, res) => {
  try {
    const updatedTodo = await Todo.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedTodo) {
      return res.status(404).json({ message: 'Todo not found' });
    }
    res.json({message:'todo updated successfully',updatedTodo});
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


const deleteTodo = async (req, res) => {
  try {
    const todo = await Todo.findByIdAndDelete(req.params.id);

    if (!todo) {
      return res.status(404).json({ message: 'Todo not found' });
    }

    res.json({ message: 'Todo deleted successfully', todo });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};



module.exports={
  getTodo,
  createTodo,
  updateTodo,
  deleteTodo
}