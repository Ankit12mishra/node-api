const nodemailer = require('nodemailer');

const mailer = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'sriom0812@gmail.com',
    pass: 'fzbg vskz cwdq kaht' // Use environment variable in production!
  }
});

module.exports = mailer;
