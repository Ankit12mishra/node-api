const mailer = require('../Config/mailConfig.js');

const sendMail = async (req, res) => {
  const mailDetails = {
    from: 'sriom0812@gmail.com',
    to: 'ankitmishra790525@gmail.com',
    subject: 'Today sending email for email sender API',
    text: 'This email sent for only testing purpose'
  };

  mailer.sendMail(mailDetails, (error, info) => {
    if (error) {
      console.error("Error sending email:", error);
      return res.status(500).send('Error sending email');
    }
    console.log("Email sent:", info.response);
    res.status(200).send('Email sent successfully');
  });
};


module.exports = { sendMail }