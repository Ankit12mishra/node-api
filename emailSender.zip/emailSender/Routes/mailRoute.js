const express = require('express');
const router = express.Router();
const mailController = require('../Controllers/mailController.js');

router.get('/send-email', mailController.sendMail);

module.exports = router;
