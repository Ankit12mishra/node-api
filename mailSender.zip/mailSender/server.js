const express = require('express');
const app = express();

const nodemailer = require('nodemailer');

const sendEmail = require('./controllers/sendMail');

app.get('/', (req, res) => {
  res.send('I am Server');
});

app.get('/send-email', sendEmail);

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});