const nodemailer = require('nodemailer');

const sendMail = async (req, res) => {
  let testAccount = await nodemailer.createTestAccount();

 const transporter = nodemailer.createTransport({
  host: "smtp.ethereal.email",
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: "trevor.rowe51@ethereal.email",
    pass: "WXtFYQUmkeb4wJ8BXr",
  },
});

  let info = await transporter.sendMail({
    from: '"Hii Ankit " <ankit@gmail.com>',
    to: "ankitmishra790525@gmail.com",
    subject: "Testing Purpose 22",
    text: "Hello world?",
    html: "<b>Hello world?</b>",
  });

  console.log("Email sent:", info.messageId);
  res.json(info);
};

module.exports = sendMail;