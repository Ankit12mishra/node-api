const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());



const UserSchema = new mongoose.Schema({
  name: String,
  age: Number,
  city: String
});

const User = mongoose.model('User', UserSchema);

app.get('/', (req, resp) => {
  resp.send('Hello World!');
})

app.get('/allDataGet', (req, resp) => {
  const data = [
    {
      name: 'John Doe',
      age: 30,
      city: 'New York'
    },
    {
      name: 'John makale',
      age: 40,
      city: 'london'
    }
  ];
  resp.json(data);
});


app.post('/allDataPost', (req, resp) => {
  const newData = req.body;
  console.log('Received data:', newData);

  resp.json({
    message: 'Data received successfully',
    data: newData
  });
});

app.put('/allDataPut', (req, resp) => {
  const updatedData = req.body;
  console.log('Updated data:', updatedData);

  resp.json({
    message: 'Data updated successfully',
    data: updatedData
  });
});

app.delete('/allDataDelete', (req, resp) => {
  const dataId = req.body.id;
  console.log('Data to delete:', dataId);
  resp.json({
    message: 'Data deleted successfully',
    id: dataId
  });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});