const Post = require('../models/Post.js');

const getAllPosts = async (req, res) => {
  const posts = await Post.find().populate('author', 'username');
  res.json(posts);
};

const createPost = async (req, res) => {
  const post = new Post({ ...req.body });
  await post.save();
  res.status(201).json(post);
};

module.exports = {
  getAllPosts,
  createPost
}