const express = require('express');
const router = express.Router();
const { createPost, getAllPosts } = require('../controllers/postController');
const auth = require('../middlewares/authMiddleware');
const upload = require('../middlewares/uploadMiddleware');

router.get('/', getAllPosts);
router.post('/', auth, upload.single('image'), createPost);

module.exports = router;
