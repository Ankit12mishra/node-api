const express = require('express');

const app = express();

require('dotenv').config();
const postRoutes = require('./routes/postRoute.js');
const userRoutes = require('./routes/authRoute.js');
const connectDB = require('./databse/db.js');


app.use(express.json());
// app.use(errorHandler);




const PORT = process.env.PORT || 5000;

// Connect to MongoDB
connectDB(process.env.MONGO_URL);

// Routes
app.use('/api/posts', postRoutes);
app.use('/api/users', userRoutes);

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
