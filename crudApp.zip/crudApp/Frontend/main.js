const apiUrl = 'http://localhost:5000/api/items';
const form = document.getElementById('item-form');
const list = document.getElementById('items-list');

async function fetchItems() {
  const res = await fetch(apiUrl);
  const items = await res.json();
  list.innerHTML = '';
  items.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name}: ${item.description}`;
    // Update button
    const updateBtn = document.createElement('button');
    updateBtn.textContent = 'Update';
    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';

    updateBtn.addEventListener('click', () => promptUpdate(item));
    deleteBtn.addEventListener('click', () => deleteItem(item._id));

    li.append(' ', updateBtn, ' ', deleteBtn);
    list.appendChild(li);
  });
}

async function addItem(data) {
  await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  fetchItems();
}

async function deleteItem(id) {
  await fetch(`${apiUrl}/${id}`, { method: 'DELETE' });
  fetchItems();
}

async function promptUpdate(item) {
  const name = prompt('New name:', item.name);
  const description = prompt('New description:', item.description);
  if (name) {
    await fetch(`${apiUrl}/${item._id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description }),
    });
    fetchItems();
  }
}

form.addEventListener('submit', e => {
  e.preventDefault();
  const formData = new FormData(form);
  const data = { name: formData.get('name'), description: formData.get('description') };
  addItem(data);
  form.reset();
});

fetchItems();

items.forEach(item => {
  const li = document.createElement('li');
  li.className = 'list-group-item d-flex justify-content-between align-items-center';

  li.innerHTML += `
  <div class="item-card">
    <div class="item-info">
      <strong>${item.name}</strong>: ${item.description}
    </div>
    <div class="item-actions">
      <button class="btn btn-sm btn-outline-primary me-2" onclick='promptUpdate(${JSON.stringify(item).replace(/"/g, '&quot;')})'>Update</button>
      <button class="btn btn-sm btn-outline-danger" onclick="deleteItem('${item._id}')">Delete</button>
    </div>

    <form class="update-form" id="update-form-${item._id}" style="display: none;" onsubmit="submitUpdate(event, '${item._id}')">
      <input type="text" name="name" value="${item.name}" required class="form-control mb-2" />
      <input type="text" name="description" value="${item.description}" required class="form-control mb-2" />
      <button type="submit" class="btn btn-success btn-sm">Save</button>
      <button type="button" class="btn btn-secondary btn-sm" onclick="cancelUpdate('${item._id}')">Cancel</button>
    </form>
  </div>
`;


  list.appendChild(li);
});





