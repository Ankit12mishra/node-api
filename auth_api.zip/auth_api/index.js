const express = require('express');
const connectDB = require('./database/db.js');
const route = require('./routes/authroutes.js');

// const routes = require('./routes/authroutes.js')

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to MongoDB
connectDB(process.env.MONGO_URL);

// Middleware
app.use(express.json());

// Routes
app.use('/api',route);

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
