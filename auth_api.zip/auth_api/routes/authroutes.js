const express = require('express');
const router = express.Router();
const { register, login } = require('../Controllers/userControllers.js');
const { validateRegister, validateLogin } = require('../validators/authValidate.js');

// const {validateRequest} = require('../Middlewares/authMiddleware.js')
const { validateRequest } = require('../middlewares/authMiddleware.js');



router.post('/register', validateRegister, validateRequest, register);
router.post('/login', validateLogin, validateRequest, login);


module.exports=router;