const express = require('express');
const router = express.Router();
const todoController = require('../controller/todoControllers');


router.post('/add', todoController.createTodo);

module.exports = router;
