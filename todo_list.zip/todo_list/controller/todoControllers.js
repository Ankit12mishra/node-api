const todoModel = require('../models/todo');


const createTodo = async (req, res) => {
  const { task } = req.body;
  try {
    const newTodo = await todoModel.createTodo({ task });
    res.status(201).json(newTodo);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create todo' });
  }
};
