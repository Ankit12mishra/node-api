const express = require('express');
const multer = require('multer');
const path = require('path');
const File = require('../models/File');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) =>
    cb(null, `${Date.now()}-${file.originalname}`)
});

const upload = multer({ storage });

router.post('/upload', upload.single('file'), async (req, res) => {
  const file = req.file || req.body;
  res.status(200).json({message:"File is uploaded successfully"})

  if (!file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }

  const newFile = await File.create({
    originalName: file.originalname,
    filename: file.filename,
    path: file.path,
    size: file.size
  });

  res.status(201).json(newFile);
});


//  List all uploaded files
router.get('/files', async (req, res) => {
  const files = await File.find().sort({ uploadedAt: -1 });
  res.json(files);
});

module.exports = router;
