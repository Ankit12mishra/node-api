const express = require('express');
const uploadRoutes = require('./routes/uploadRoutes.js');


const app = express();

require('dotenv').config();

const connectDB = require('./dabase/db.js');

app.use(express.json());

app.use('/uploads', express.static('uploads')); // Serve uploaded files
app.use('/api', uploadRoutes);

const PORT = process.env.PORT || 5000;

connectDB(process.env.MONGO_URL);

  app.listen(PORT, ()=>{
    console.log(`Server is running on port ${PORT}`);
  });