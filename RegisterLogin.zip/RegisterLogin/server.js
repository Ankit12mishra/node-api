const express = require('express');
const connectDB = require('./config/db.js');
const authRoutes = require('./routes/authroutes.js');
require('dotenv').config();

const validate = require('./middleware/validate.js');
const registerSchema = require('./validators/valiDate');

const PORT = process.env.PORT || 5000;

const app = express();

// Connect to MongoDB
connectDB(process.env.MONGO_URL);

connectDB();

app.use(express.json());

// app.use('/api/auth', authRoutes);

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


app.get('/register', validate(registerSchema), (req, res) => {
  
  // your register handler
})