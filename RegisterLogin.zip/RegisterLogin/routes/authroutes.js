const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController.js');
const validate = require('../middleware/validate.js');
const registerSchema = require('../validators/valiDate');


const { registerSchema, loginSchema ,updateProfile} = require('../controllers/authController.js');
const registerSchema = require('../validators/valiDate.js')

router.get('/register', validate(registerSchema),authController.register);
  router.post('/login', validate(loginSchema), authController.login);
  router.put('/update-profile/:id', upload.single('profileImage'), updateProfile);


module.exports = router;
