const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth.js');
const User = require('../models/user.js');
const authController = require('../controllers/authControllers.js')



router.post('/create', authController.userCreate);
router.put('/update/:id', authController.userUpdate);


module.exports = router;
