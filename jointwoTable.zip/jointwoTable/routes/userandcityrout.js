const express = require('express');
const router = express.Router();
const { addCity } = require('../controllers/studentController.js');

router.post('/addCity', addCity);


const { addStudent, getStudents } = require('../controllers/studentController.js');

router.post('/addStudent', addStudent);
router.get('/getStudent', getStudents);

module.exports = router;
