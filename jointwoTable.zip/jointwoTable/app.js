const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const connectDB = require('./database/db.js');


const cityRoutes = require('./routes/userandcityrout.js');
const studentRoutes = require('./routes/userandcityrout.js');




const app = express();
app.use(bodyParser.json());


require('dotenv').config();

const PORT = process.env.PORT || 3000;

// Connect to MongoDB
connectDB(process.env.MONGO_URL);

// Middleware
app.use(express.json());


app.use('/cities', cityRoutes);
app.use('/students', studentRoutes);


// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

