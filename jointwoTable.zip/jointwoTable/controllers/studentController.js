const City = require('../models/city');
const Student = require('../models/student');




// Add new city
exports.addCity = async (req, res) => {
    try {
        const city = new City({ name: req.body.name });
        await city.save();
        res.status(201).json(city);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Add new student
exports.addStudent = async (req, res) => {
    try {
        const student = new Student({
            name: req.body.name,
            cityId: req.body.cityId
        });
        await student.save();
        res.status(201).json(student);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Get all students with city name populated
exports.getStudents = async (req, res) => {
    try {
        const students = await Student.find().populate('cityId', 'name');
        res.status(200).json(students);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
